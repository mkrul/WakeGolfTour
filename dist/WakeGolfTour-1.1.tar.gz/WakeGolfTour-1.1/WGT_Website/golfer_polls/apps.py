from django.apps import AppConfig


class GolferPollsConfig(AppConfig):
    name = 'golfer_polls'
